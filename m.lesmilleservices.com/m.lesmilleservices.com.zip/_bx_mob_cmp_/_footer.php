<div class="boreder shadow bg-primary" style="position:fixed;float:right;right:0px;padding:1px 1px;bottom:5px;z-index:40000;width:60px;height:60px;line-height:60px;text-align:center;border-radius:50% 0 0 50%">
    <div class="row">
      <div class="col-lg-6"></div>
      <div class="col-lg-6"></div>
    </div>
    <div class="w-100 circle border">
        <!-- <img src="./_bx_assoc_imgs_/_bx_banners_/thumb.png" alt="Assistant"> -->
    </div>
</div>
<footer class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="footer-left">
                        <div class="footer-logo">
                            <a href="?_route=home"><img src="../_bx_assoc_imgs_/vraiefooter.png" alt="logo footer"></a>
                        </div>
                        <ul>
                            <li>
                                <span  class="fa fa-map-marker"></span>
                                 Blvrd Kanyamuhanga,habamungu building | RDC - Goma
                            </li>
                            <li>
                                <ul>
                                    <li>
                                        <span class="fa fa-phone"></span>
                                        +243 992 913 458
                                    </li>
                                    <li>
                                        <span class="fa fa-phone"></span>
                                        +243 815 864 596
                                    </li>
                                </ul>
                            </li>
                            <li>
                               <span class="fa fa-envelope"></span>
                                <em> contact@lesmilleservices.com</em>
                            </li>
                        </ul>
                        <div class="footer-social">
                            <a href="https://www.facebook.com/Les-Mille-Services-406094873225056/"><i class="fa fa-facebook"></i></a>
                            <!-- <a href="#"><i class="fa fa-instagram"></i></a> -->
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="https://www.linkedin.com/company/38093245/admin/" title="nous suivre sur linkedin" target="blank"><i class="ti-linkedin"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 offset-lg-1">
                    <div class="footer-widget">
                        <h5>Informations</h5>
                        <ul>
                            <li><a href="?page=_contact">About Us</a></li>
                            <li><a href="?page=_faqPage">Informations</a></li>
                            <li><a href="?page=_contact">Contact</a></li>
                            <!-- <li><a href="#">Serivius</a></li> -->
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="footer-widget">
                        <h5>Mon compte</h5>
                        <ul>
                            <li><a href="?page=_account">Mon compte</a></li>
                            <li><a href="?page=_commandes">Mes commandes</a></li>
                            <!-- <li><a href="#">Mode de paiement</a></li> -->
                            <li><a href="?page=_myShop">Location | Achat</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="newslatter-item">
                        <h5>Rejoignez notre Newsletter</h5>
                        <p>Recevez reguli&egrave;rement les nouvelles de nos produits</p>
                        <form action="#" class="subscribe-form" id="subscribeForm">
                            <input type="email" name="emForSubs" placeholder="Adresse mail ici ..." id="mailSub">
                            <button type="button" name="subscrib" id="onSubscib">Inscription</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-reserved">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright-text">
                            
                        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | by <a href="#" target="_blank" class="text-primary">les 1000 Services</a>

                        </div>
                        <div class="payment-pic">
                            <!-- <img src="img/payment-method.png" alt=""> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <script src="../js/_onSubscribe.js"></script>