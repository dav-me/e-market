<style>
    .active_p a{
        background: #1a82db;
    }
</style>
 <!-- Breadcrumb Section Begin -->
 <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="?page=home"><i class="fa fa-home"></i> Home</a>
                        <a href="#"> Pages</a>
                        <span>A propos de nous</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->
   <!-- Faq Section Begin -->
    <div class="faq-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="faq-accordin">
                        <div class="col-lg-12 w-100 p-2 border shadow mb-2">
                           <p>Rccm : <b>CD/GOM/RCCM/19-B-0863</b></p>
                           <p>Id nat: <b>B-83-N-49852Q</b></p>
                           <p>Impôt:  <b>A1913711A</b></p>
                        </div>
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-heading active">
                                    <a class="active" data-toggle="collapse" data-target="#collapseOne">
                                        Y a-t-il quelque chose que je devrais apporter ?
                                    </a>
                                </div>
                                <div id="collapseOne" class="collapse show" data-parent="#accordionExample">
                                    <div class="card-body p-3 bg-default">
                                        <p>
                                            Pour une raison de sécurité de tout le monde nos services clients, démandent d'apporter aumoins une piece d'identité, 
                                            à nos clients car cette dernière vous permettra d'acceder à nos inslallations <span class="badge badge-primary">Les 1000 services.</span> 
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-heading">
                                    <a data-toggle="collapse" data-target="#collapseTwo">  
                                        Où puis-je trouver des rapports d'études de marché ?
                                    </a>
                                </div>
                                <div id="collapseTwo" class="collapse" data-parent="#accordionExample">
                                    <div class="card-body p-3">
                                        <p>Pour plus d'informations passez à nos installations à Goma. En République Démocratique du Congo</p>
                                        <p>En voiture, On assure</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-heading">
                                    <a data-toggle="collapse" data-target="#collapseThree">
                                        Où puis-je trouver vos coordonnées ?
                                    </a>
                                </div>
                                <div id="collapseThree" class="collapse" data-parent="#accordionExample">
                                    <div class="card-body p-3">
                                        <p>Nos services clients sont joignables <span class="badge badge-warning">7 jours / 7 jours</span> sur nos numeros de services
         
                                            <p><span class="fa fa-phone"></span>&nbsp;<span class="badge badge-warning"> +243 974 228 949</span></p>
                                            <p><span class="fa fa-phone"></span>&nbsp;<span class="badge badge-warning"> +243 815 864 596</span></p>
                                            <p><span class="fa fa-phone"></span>&nbsp;<span class="badge badge-warning"> +243 974 739 246</span></p>
                                            ou nous faire un courrier sur <span class="badge badge-primary">contact@lesmilleservices.com</span> <a href="?page=_contact" class="btn btn-default">Contact us</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Faq Section End -->