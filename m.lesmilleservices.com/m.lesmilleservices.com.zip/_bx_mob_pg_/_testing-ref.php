<?php 

#<a href="https://lesmilleservices.com/?page=_verify-mail-me&tkn_='.$tkn.'&cmpl='.$cmpl.'&em='.$email.'&id_rec='.$id.'" target="_blank" rel="noopener noreferrer">href="https://lesmilleservices.com/?page=_verify-mail-me&tkn_='.$tkn.'&cmpl='.$cmpl.'&em='.$email.'&id_rec='.$id.'"</a>
_onVerifyMail(6,$bdd)
?>